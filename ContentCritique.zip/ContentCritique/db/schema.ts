import { pgTable, text, serial, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  isAdmin: boolean("is_admin").default(false).notNull(),
  inviteCode: text("invite_code").unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User Foundation (their saved setup)
export const userFoundations = pgTable("user_foundations", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").notNull().references(() => users.id),
  
  // Brand Deep-Dive Answers
  targetAudience: text("target_audience"),
  audiencePainPoints: text("audience_pain_points"),
  uniquePositioning: text("unique_positioning"),
  competitorDifferences: text("competitor_differences"),
  commonObjections: text("common_objections"),
  brandValues: text("brand_values"),
  
  // Voice & Tone Guide
  voiceGuide: text("voice_guide"),
  
  // Audience Observations
  audienceObservations: text("audience_observations"),
  
  // Business Context
  offerDescription: text("offer_description"),
  businessContext: text("business_context"),
  
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Feedback requests (updated to link to users)
export const feedbackRequests = pgTable("feedback_requests", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  content: text("content").notNull(),
  toolType: text("tool_type").notNull(),
  feedback: text("feedback").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Invite codes
export const inviteCodes = pgTable("invite_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  isUsed: boolean("is_used").default(false).notNull(),
  usedBy: serial("used_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  usedAt: timestamp("used_at"),
});

export const insertUserSchema = createInsertSchema(users);
export const selectUserSchema = createSelectSchema(users);
export const insertUserFoundationSchema = createInsertSchema(userFoundations);
export const selectUserFoundationSchema = createSelectSchema(userFoundations);
export const insertFeedbackRequestSchema = createInsertSchema(feedbackRequests);
export const selectFeedbackRequestSchema = createSelectSchema(feedbackRequests);
export const insertInviteCodeSchema = createInsertSchema(inviteCodes);
export const selectInviteCodeSchema = createSelectSchema(inviteCodes);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type UserFoundation = typeof userFoundations.$inferSelect;
export type InsertUserFoundation = typeof userFoundations.$inferInsert;
export type FeedbackRequest = typeof feedbackRequests.$inferSelect;
export type InsertFeedbackRequest = typeof feedbackRequests.$inferInsert;
export type InviteCode = typeof inviteCodes.$inferSelect;
export type InsertInviteCode = typeof inviteCodes.$inferInsert;
